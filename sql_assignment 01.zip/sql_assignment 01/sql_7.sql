select avg(IMDBScore) as avg_score , GenreID from netflix_orginals
group by genreID
having count(genreID)>=10;