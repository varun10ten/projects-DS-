select count(Title) as Title_count , Language, Premiere_Date from netflix_orginals
where Premiere_Date between '2020-01-01' and '2020-12-31'
group by Language
having Title_count;
