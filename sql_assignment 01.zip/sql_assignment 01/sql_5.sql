select * from netflix_orginals;
select Title , Premiere_Date from netflix_orginals
where Premiere_Date between '2018-01-01' and '2020-12-31' 
and (Language="Hindi" or Language="English" or Language="Spanish");