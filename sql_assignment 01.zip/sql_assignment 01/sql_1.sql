select * from netflix_orginals
where IMDBScore>7 and Runtime>100 and (Language ='English' OR Language='Spanish');


