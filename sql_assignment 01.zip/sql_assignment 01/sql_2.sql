select * from netflix_orginals;
select Language, count(Title) as title from netflix_orginals group by Language having count(Title)>5;  
