select * from netflix_orginals;
select Title , IMDBScore from netflix_orginals
where Title like "%House%"
and IMDBScore>6;
