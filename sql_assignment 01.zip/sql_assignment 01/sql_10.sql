create table new_netflix(
Title varchar(200),
GenreID varchar(5),
Runtime int check (Runtime>30),
IMDBScore float check (IMDBScore between 0 and 10),
Language varchar(50),
Premiere_Date date);

select * from new_netflix;