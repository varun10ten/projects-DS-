select Title,Runtime,IMDBScore,Premiere_Date from netflix_orginals
where Runtime<60 or IMDBScore<5 
order by Premiere_Date desc;