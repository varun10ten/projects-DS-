select * from netflix_orginals;
select Title , IMDBScore, Runtime from netflix_orginals
where Language = 'Hindi'
order by IMDBScore desc, runtime desc
limit 3;
