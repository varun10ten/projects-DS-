 select Runtime, Title , count(*) as common from netflix_orginals
group by Runtime
order by count(*) desc
limit 5;