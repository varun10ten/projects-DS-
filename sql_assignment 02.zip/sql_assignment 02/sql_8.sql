select gs.GameID, gs.Platform, gs.SalesRegion, gs.UnitsSold
from game_sales gs
left join games g on gs.GameID = g.GameID
where g.GameID is null;
