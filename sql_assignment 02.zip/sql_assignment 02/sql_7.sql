select g.GameID, g.GameTitle, gs.Platform, gs.SalesRegion, gs.UnitsSold
from games g
left join game_sales gs on g.GameID = gs.GameID;

