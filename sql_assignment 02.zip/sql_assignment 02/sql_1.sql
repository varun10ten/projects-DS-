select * from games;
insert into games values (151,"Future Racing","Racing","2024-10-01","Speed Studios");
