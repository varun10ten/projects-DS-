Identify the game with the highest number of units sold in North America
select * from games;
select * from game_sales;
select g.GameTitle, gs.UnitsSold , gs.SalesRegion from game_sales gs
inner join games g on gs.GameID=g.GameID
where gs.SalesRegion = 'North America'
group by g.GameTitle
order by gs.UnitsSold desc
limit 5;