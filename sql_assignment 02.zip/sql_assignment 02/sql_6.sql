select g.GameID, g.GameTitle , gs.Platform,gs.SalesRegion , gs.UnitsSold from game_sales gs
inner join games g on gs.GameID= g.GameID;

