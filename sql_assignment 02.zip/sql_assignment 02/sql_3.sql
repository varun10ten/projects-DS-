select * from game_sales;
delete from game_sales 
where GameID = 5;