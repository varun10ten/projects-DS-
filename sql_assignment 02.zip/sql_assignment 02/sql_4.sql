select * from game_sales;
select * from games;
select g.GameTitle , gs.Platform , gs.SalesRegion, sum(gs.UnitsSold) as total_sales
from game_sales gs
left join games g on gs.GameID=g.GameID
group by gs.SalesRegion,gs.Platform,g.GameTitle;

