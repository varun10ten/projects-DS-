select * from game_sales;
-- SET SQL_SAFE_UPDATES = 0;
update game_sales
set Price=60 where GameID=2;