select distinct gs.GameID, g.GameTitle , gs.SalesRegion, gs.Platform,gs.Price,gs.UnitsSold
from game_sales as gs
inner join games g on gs.GameID=g.GameID
where gs.SalesRegion in ("North America", "Europe");


